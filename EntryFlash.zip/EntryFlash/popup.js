document.addEventListener('DOMContentLoaded', () => {
  const clearButton = document.getElementById('clear');
  const modal = document.getElementById('confirmModal');
  const modalMessage = document.getElementById('modalMessage');
  const confirmYes = document.getElementById('confirmYes');
  const confirmNo = document.getElementById('confirmNo');

  function showModal(message, showNoButton = true) {
      modalMessage.textContent = message;
      modal.style.display = 'flex';
      modal.classList.add('show');
      modal.classList.remove('hide');
      
      confirmNo.style.display = showNoButton ? 'inline-block' : 'none';
  }

  function hideModal() {
      modal.classList.add('hide');
      modal.classList.remove('show');
      
      setTimeout(() => {
          modal.style.display = 'none';
          modal.classList.remove('hide');
      }, 300);
  }

  clearButton.addEventListener('click', async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const url = new URL(tab.url);

      if (url.hostname === 'playentry.org') {
          showModal('정말로 클리너를 작동하시겠습니까? 로그아웃이 진행됩니다.', true);

          confirmYes.onclick = async () => {
              await chrome.browsingData.remove({
                  "origins": [url.origin]
              }, {
                  "cookies": true,
                  "cacheStorage": true,
                  "localStorage": true,
                  "webSQL" : true,
                  "indexedDB": true,
                  "appcache": true
              });
              chrome.tabs.reload(tab.id);
              hideModal(); 
              window.close(); 
          };

      } else {
          showModal('이 확장 프로그램은 엔트리 사이트에서만 사용할 수 있습니다.', false);

          confirmYes.onclick = () => {
              hideModal();
          };
      }

      confirmNo.onclick = () => {
          hideModal();
      };
  });
});
