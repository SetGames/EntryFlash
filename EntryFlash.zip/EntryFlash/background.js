chrome.action.onClicked.addListener(async (tab) => {
    const url = new URL(tab.url);
  
    if (url.hostname === 'playentry.org') {
      await chrome.browsingData.remove({
        "origins": [url.origin]
      }, {
        "cookies": true,
        "cacheStorage": true,
        "localStorage": true,
        "webSQL" : true,
        "indexedDB": true,
        "appcache": true
      });
  
      chrome.tabs.reload(tab.id);  
    }
  });
  